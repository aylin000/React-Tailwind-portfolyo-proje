import React from "react";
const skills = ["React", "Tailwind CSS", "JavaScript", "HTML", "CSS", "AI Integration"];
export default function Skills() {
  return (
    <section className="p-6 bg-gray-50 dark:bg-gray-800 transition-colors duration-500">
      <h3 className="text-2xl font-bold mb-4">Yeteneklerim</h3>
      <div className="flex flex-wrap gap-4">
        {skills.map((skill, i) => (<span key={i} className="px-3 py-1 bg-gray-200 dark:bg-gray-700 rounded">{skill}</span>))}
      </div>
    </section>
  );
}