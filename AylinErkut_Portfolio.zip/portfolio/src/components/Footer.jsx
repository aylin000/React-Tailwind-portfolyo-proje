import React from "react";
export default function Footer() {
  return (
    <footer className="p-6 text-center bg-gray-100 dark:bg-gray-800 transition-colors duration-500">
      <p>© 2025 Aylin Erkut. Tüm hakları saklıdır.</p>
    </footer>
  );
}