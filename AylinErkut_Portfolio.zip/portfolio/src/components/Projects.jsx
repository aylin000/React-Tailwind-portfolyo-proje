import React from "react";
const projectList = [
  { title: "Portfolio Website", desc: "Kendi portfolyomu React ile tasarladım." },
  { title: "E-commerce UI", desc: "AI destekli ürün sayfası ve alışveriş sepeti." },
];
export default function Projects() {
  return (
    <section className="p-6">
      <h3 className="text-2xl font-bold mb-4">Projelerim</h3>
      <div className="grid md:grid-cols-2 gap-4">
        {projectList.map((p, i) => (
          <div key={i} className="p-4 border rounded shadow hover:scale-105 transition-transform duration-300">
            <h4 className="font-semibold">{p.title}</h4>
            <p>{p.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}