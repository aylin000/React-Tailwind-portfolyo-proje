import React from "react";
const educationList = [
  { school: "XYZ Üniversitesi", degree: "Bilgisayar Mühendisliği", year: "2021-2025" },
  { school: "ABC Lisesi", degree: "Fen Lisesi", year: "2017-2021" }
];
export default function Education() {
  return (
    <section className="p-6">
      <h3 className="text-2xl font-bold mb-4">Eğitim</h3>
      <ul className="space-y-2">
        {educationList.map((edu, i) => (
          <li key={i} className="border p-3 rounded hover:shadow-md transition-shadow">
            <strong>{edu.school}</strong> - {edu.degree} ({edu.year})
          </li>
        ))}
      </ul>
    </section>
  );
}