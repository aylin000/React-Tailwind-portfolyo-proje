import React from "react";
export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col justify-center items-center text-center p-4">
      <h2 className="text-4xl font-bold mb-4 fade-in">Merhaba, ben Aylin Erkut</h2>
      <p className="text-lg mb-6 fade-in">Frontend Developer | React & Tailwind CSS | AI destekli projeler</p>
    </section>
  );
}